# MomsMovies

My wife, Debby, is a rabid movie / DVD collector. A few years ago things were getting out of hand as the collection grew. At that time a catalog was started using Excel and/or OpenOffice Calc. As expected the data checks and functionalities were primative of non-existent.

Now, here's an opposrtunity for the python Sqlite database application I have been intending to take advanage of. This is a very common kind of first database project and there is no dearth of such apps out there - but who can resist writing their own. This is especially so because I am still learning the ins and outs of writing python applications and python database access.

